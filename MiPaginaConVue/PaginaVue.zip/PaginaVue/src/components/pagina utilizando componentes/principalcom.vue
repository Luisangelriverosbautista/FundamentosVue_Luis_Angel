<script setup>
import navs from './nav.vue';
import carrusel from './carrusel.vue';
import Cards from './cards.vue';


</script>

<template >
  <div class="container">
  <navs/>
        <!-- empieza carrucel -->
        <carrusel/>
        <!-- termina carrucel -->
        
    </div>
    <br>
    <br>
    <br>
    <br>
    <Cards/>

</template>

<style scoped></style>